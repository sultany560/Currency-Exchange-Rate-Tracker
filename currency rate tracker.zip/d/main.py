# main.py

import streamlit as st  # Streamlit helps us create a web app using only Python

# Import the classes we just defined
from config import SUPPORTED_CURRENCIES
from components.exchange_api import ExchangeAPI
from components.converter import CurrencyConverter
from components.visuals import Visualizer
from components.multi_converter import MultiCurrencyConverter
from components.predictor import RatePredictor

# ----- CONFIGURE YOUR API KEY HERE -----
API_KEY = "ceb40410fafebdcc64f9ca85bcc5395c"
# ----------------------------------------

# Create an instance of the ExchangeAPI class with your API key
exchange_api = ExchangeAPI(access_key=API_KEY)

# Set up the Streamlit page: title, icon, and layout
st.set_page_config(page_title="Currency Exchange Tracker", page_icon="💱", layout="centered")

# Display the main title of the web app
st.title("💱 Currency Exchange Rate Tracker")

# Create a sidebar menu so the user can pick a feature
menu = st.sidebar.radio("Select Feature", [
    "📈 Live Rates Overview",
    "💵 Currency Converter",
    "📊 Exchange Rate Trends",
    "💸 Multi-Currency Converter",
    "🔬 Predict Future Rates"
])

# Let the user choose a base currency (starting currency) from a dropdown
# base_currency = st.sidebar.selectbox("Base Currency", SUPPORTED_CURRENCIES)
base_currency = st.sidebar.selectbox("Base Currency (Free plan only supports EUR)", ["EUR"])

# Fetch the latest exchange rates (returns a dict like {"USD":1.12, "GBP":0.85, ...})
rates = exchange_api.fetch_latest_rates(base_currency=base_currency)

# If no rates were returned (maybe API key is wrong or no internet), show an error
if not rates:
    st.error("Could not fetch exchange rates. Please check your internet connection or API key.")

# ---------------------------------------------------------------------------------
# 1) Live Rates Overview
# ---------------------------------------------------------------------------------
elif menu == "📈 Live Rates Overview":
    st.subheader("📈 Current Exchange Rates")
    st.write(f"Base currency: **{base_currency}**")
    # Show a table of all supported currencies with their current rates
    display_data = {cur: round(rate, 4) for cur, rate in rates.items() if cur in SUPPORTED_CURRENCIES}
    st.table(display_data)

# ---------------------------------------------------------------------------------
# 2) Single Currency Converter
# ---------------------------------------------------------------------------------
elif menu == "💵 Currency Converter":
    st.subheader("💵 Convert Currency")
    from_currency = st.selectbox("From", SUPPORTED_CURRENCIES)
    to_currency = st.selectbox("To", SUPPORTED_CURRENCIES)
    amount = st.number_input("Amount", min_value=0.0, value=100.0)

    if st.button("Convert"):
        converter = CurrencyConverter(rates)
        converted_value = converter.convert(amount, from_currency, to_currency)
        st.success(f"{amount:.2f} {from_currency} = {converted_value:.2f} {to_currency}")

# ---------------------------------------------------------------------------------
# 3) Exchange Rate Trends (Visualization)
# ---------------------------------------------------------------------------------
elif menu == "📊 Exchange Rate Trends":
    st.subheader("📊 Exchange Rate Trends")
    visualizer = Visualizer()
    fig = visualizer.plot_exchange_trends(base_currency, rates, SUPPORTED_CURRENCIES)
    st.pyplot(fig)

# ---------------------------------------------------------------------------------
# 4) Multi-Currency Converter
# ---------------------------------------------------------------------------------
elif menu == "💸 Multi-Currency Converter":
    st.subheader(f"💸 Convert {base_currency} to Multiple Currencies")
    amount = st.number_input("Amount in Base Currency", min_value=0.0, value=100.0)

    if st.button("Convert All"):
        multi_conv = MultiCurrencyConverter(rates)
        results = multi_conv.convert_to_all(amount, base_currency, SUPPORTED_CURRENCIES)
        st.table(results)

# ---------------------------------------------------------------------------------
# 5) Predict Future Rates
# ---------------------------------------------------------------------------------
elif menu == "🔬 Predict Future Rates":
    st.subheader("🔬 Predict Future Exchange Rate")
    target_currency = st.selectbox(
        "Select currency to predict",
        [c for c in SUPPORTED_CURRENCIES if c != base_currency]
    )
    days = st.slider("Days to forecast", 1, 30)

    predictor = RatePredictor(rates)
    future_values = predictor.predict(base_currency, target_currency, days)

    if future_values is not None and len(future_values) > 0:
        forecast_dict = {f"Day +{i+1}": float(future_values[i]) for i in range(len(future_values))}
        st.line_chart(forecast_dict)
    else:
        st.warning("Prediction unavailable due to data limitations.")

st.markdown("---")
st.caption("Powered by exchangeratesapi.io | Built by Yusuf, Doris, Aisha and Peter")
