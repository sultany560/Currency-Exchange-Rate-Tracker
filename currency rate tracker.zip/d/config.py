# config.py

# List of supported currency codes
SUPPORTED_CURRENCIES = [
    "EUR", "USD", "GBP", "JPY", "NGN", "AUD", "CAD", "CHF", "CNY", "INR"
]
