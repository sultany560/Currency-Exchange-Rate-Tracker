# multi_converter.py

class MultiCurrencyConverter:
    """
    This class converts a single amount in one base currency into all other
    supported currencies at once.
    """

    def __init__(self, rates: dict):
        """
        Store the rates dictionary when creating the object.
        """
        self.rates = rates

    def convert_to_all(self, amount: float, base_currency: str, supported: list) -> dict:
        """
        Convert ‘amount’ from base_currency into each currency in ‘supported’.
        Returns a dictionary where keys are currency codes and values are converted amounts.
        """
        results = {}
        for target in supported:
            if target not in self.rates:
                # Skip unsupported currency
                results[target] = None
            else:
                amount_in_eur = amount / self.rates[base_currency]
                results[target] = round(amount_in_eur * self.rates[target], 4)
        return results
