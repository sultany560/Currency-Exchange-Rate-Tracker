# converter.py

class CurrencyConverter:
    """
    This class takes a dictionary of exchange rates and can convert amounts 
    from one currency to another.
    """

    def __init__(self, rates: dict):
        """
        When creating a converter, supply a rates dictionary like:
        {"USD": 1.12, "GBP": 0.85, ...}
        We store it for later conversions.
        """
        self.rates = rates

    def convert(self, amount: float, from_curr: str, to_curr: str) -> float:
        """
        Convert a numeric amount from one currency to another.
        - amount: how much money you have in from_curr.
        - from_curr: the currency code you have (e.g., "USD").
        - to_curr: the currency code you want (e.g., "GBP").

        Returns the converted amount in to_curr, rounded to 4 decimals.
        """
        # If the user asks to convert from and to the same currency, nothing changes
        if from_curr == to_curr:
            return round(amount, 4)

        # Each rate in self.rates is how much 1 EUR = X of that currency.
        # First, convert amount to EUR (the “common base”). 
        if from_curr not in self.rates or to_curr not in self.rates:
            # Currency not supported; return 0.0 to indicate failure
            return 0.0

        # Convert from “from_curr” to EUR
        amount_in_eur = amount / self.rates[from_curr]

        # Now convert that EUR amount into “to_curr”
        converted = amount_in_eur * self.rates[to_curr]

        return round(converted, 4)
