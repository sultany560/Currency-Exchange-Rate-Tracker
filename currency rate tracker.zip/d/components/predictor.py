# predictor.py

import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression

class RatePredictor:
    """
    This class takes past exchange rates and uses a basic linear regression model 
    to forecast future rates for a particular currency.
    """

    def __init__(self, rates: dict):
        """
        Store the current rates dictionary. 
        In real life, you’d also fetch full historical series to train on.
        """
        self.rates = rates

    def predict(self, base_currency: str, target_currency: str, days: int = 7) -> np.ndarray:
        """
        Predicts the next `days` days of exchange rates for target_currency.
        Returns a NumPy array of length `days` with predicted values.
        """
        # Build a fake history DataFrame (30 days) for demonstration
        dates = pd.date_range(end=pd.Timestamp.now(), periods=30)
        current_rate = self.rates.get(target_currency, 1.0)
        past_rates = [round(current_rate - i * 0.01, 4) for i in range(len(dates))]

        df = pd.DataFrame({
            "day": np.arange(len(dates)),
            "rate": past_rates[::-1]  # reverse so index 0 is oldest
        })

        model = LinearRegression()
        X = df[["day"]]
        y = df["rate"]
        model.fit(X, y)

        future_days = np.arange(len(dates), len(dates) + days).reshape(-1, 1)
        predictions = model.predict(future_days)

        return np.round(predictions, 4)
