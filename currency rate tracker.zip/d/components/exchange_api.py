# exchange_api.py

import requests

class ExchangeAPI:
    """
    This class handles connecting to the exchangeratesapi.io service
    and fetching up-to-date exchange rates.
    """

    def __init__(self, access_key: str):
        """
        When you create an ExchangeAPI object, you must give it your API key.
        It also sets up a requests.Session to reuse the same network connection.
        """
        # Base URL for all API calls (v1 of exchangeratesapi.io)
        self.base_url = "http://api.exchangeratesapi.io/v1"
        # Your unique access key (from the exchangeratesapi.io dashboard)
        self.access_key = access_key
        # Create a session object to reuse HTTP connection
        self.session = requests.Session()

    def fetch_latest_rates(self, base_currency: str = "EUR") -> dict:
        """
        Fetches the latest exchange rates from the server.
        - base_currency: (e.g. "EUR", "USD") — but on a free plan, only "EUR" works.
        Returns a dictionary like {"USD": 1.1234, "GBP": 0.8765, ...}
        If something goes wrong, returns an empty dict.
        """
        # Build the URL endpoint for the “latest” resource
        endpoint = f"{self.base_url}/latest"
        # Query parameters include the access key and (optionally) base
        params = {
            "access_key": self.access_key
            # On free plan, we cannot override base; it stays EUR.
            # If you had a paid plan, you could add "base": base_currency here.
        }

        try:
            # Make the HTTP GET request with the parameters
            response = self.session.get(endpoint, params=params)
            # 💡 ADD THESE TWO PRINTS:
            print("URL CALLED:", response.url)
            print("RESPONSE TEXT:", response.text)
            # Check if the server replied with a success status (200 OK)
            response.raise_for_status()

            # Convert the JSON response into a Python dictionary
            data = response.json()

            # If the response does not contain "rates", something is wrong
            if "rates" not in data:
                # We choose to return an empty dict in that case
                return {}

            # Otherwise, return the "rates" subsection
            return data["rates"]

        except requests.exceptions.RequestException:
            # If the network request fails (no internet, wrong key, etc.), return empty dict
            return {}
