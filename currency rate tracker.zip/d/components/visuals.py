# visuals.py

import matplotlib.pyplot as plt
import pandas as pd

class Visualizer:
    """
    This class holds functions to create and show charts—specifically, 
    plotting how a particular currency’s exchange rate has changed over time.
    """

    @staticmethod
    def plot_exchange_trends(base_currency: str, rates: dict, supported: list):
        """
        Creates a line chart (using Matplotlib) of exchange rates
        for each supported currency over sample dates.
        Returns a Matplotlib figure object that Streamlit can display.
        """
        # Sample dates for demonstration
        dates = ["2025-05-20", "2025-05-21", "2025-05-22", "2025-05-23", "2025-05-24"]
        data = {}
        for currency in supported:
            if currency not in rates:
                continue
            current = rates[currency]
            data[currency] = [round(current - i * 0.01, 4) for i in range(len(dates))]

        df = pd.DataFrame(data, index=pd.to_datetime(dates))

        fig, ax = plt.subplots()
        for col in df.columns:
            ax.plot(df.index, df[col], marker='o', label=col)

        ax.set_title(f"Exchange Rate Trends (Base: {base_currency})")
        ax.set_xlabel("Date")
        ax.set_ylabel("Rate")
        ax.legend(title="Currency")
        ax.grid(True)

        return fig
